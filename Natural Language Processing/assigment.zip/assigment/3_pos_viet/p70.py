
import re

def lam_sach_dau_vao(a_str: str) -> []:
    pattern = r'<\s*w\s*pos="(.*?)"\s*>\s*(.*?)\s*</\s*w>'
    return re.findall(pattern, a_str)



if __name__ == '__main__':
    corpus = '<w pos="Nc"> back </w> <w pos="Vto"> up </w> <w pos="Nn"> six </w> <w pos=","> , </w> <w pos="Vs"> yes </w> <w pos="Nu"> times </w> <w pos="Pp"> I </w> <w pos="Jt"> did </w> <w pos="Vt"> look </w> <w pos="Vt"> see </w> <w pos="Nn"> one </w> <w pos="Nt" > picture </w> <w pos="Nc"> picture </w> <w pos="Jd"> great </w> <w pos="Aa"> beautiful </w>'
    samples = lam_sach_dau_vao(corpus)

    sentence = '<w pos="Nc"> back </w> <w pos="Adv"> up </w> < w pos="Nn"> six </w> <w pos=","> , </ w> <w pos="Vs"> yes </w> <w pos="Nu"> times </w> <w pos="Pp"> I </w> <w pos="JJ"> did </w> <w pos="Vt"> look </w> <w pos="Vt"> see </w> <w pos="Nn"> one </w> <w pos="Nt" > picture </w> <w pos="Nc"> picture </w> <w pos="Jd"> great </w> <w pos="Aa"> beautiful </w>'

    sentences = lam_sach_dau_vao(sentence)
    print(samples)
    print(sentences)

    # Precision = number of correctly labeled words/total number of labeled words
    labeled_word_num = len(sentences)
    i = 0
    correct_label_word = 0
    while i < labeled_word_num:
        if  samples[i][0] == sentences[i][0]:
            correct_label_word += 1
            pass
        i = i + 1
        pass
    precision = correct_label_word / labeled_word_num
    # Recall = number of correctly labeled words/ total number of correct words
    total_number_of_correct_word = len(samples)
    recall = correct_label_word / total_number_of_correct_word

    print(precision, recall)
    print(labeled_word_num, total_number_of_correct_word)
    pass