

a_str = '<w pos="Nc"> back </w> <w pos="Vto"> up </w> <w pos="Nn"> six </w> <w pos=","> , </w> <w pos="Vs"> yes </w> <w pos="Nu"> times </w> <w pos="Pp"> I </w> <w pos="Jt"> did </w> <w pos="Vt"> look </w> <w pos="Vt"> see </w> <w pos="Nn"> one </w> <w pos="Nt" > picture </w> <w pos="Nc"> picture </w> <w pos="Jd"> great </w> <w pos="Aa"> beautiful </w>'

import re

pattern = r'<w pos="(.*?)"\s*>\s*(.*?)\s*</w>'
get = re.findall(pattern, a_str)
print(get)
