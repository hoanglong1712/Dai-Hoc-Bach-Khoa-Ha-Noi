#include <stdio.h>
#include <stdlib.h>

#ifdef _OPENMP
#include <omp.h>
#endif

void Hello(void); /** thread function */

int main(int argc, char ** argv){
    /* get number of thread from command line*/
    int thread_count = strtol(argv[1], NULL, 10);

# pragma omp parallel num_threads(thread_count)
    Hello();

    return 0;
}

void Hello(void){
    #ifdef _OPENMP
    int myrank = omp_get_thread_num();
    int thread_count = omp_get_num_threads();
    #else
    int myrank = 0;
    int thread_count = 0;
    #endif

    printf("Hello from thread %d of %d\n", myrank, thread_count);

}




