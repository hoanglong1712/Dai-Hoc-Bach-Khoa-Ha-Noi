

/* 
 * File:   main.c
 * Author: 12-19-11-1-2023
 *
 * Created on March 1, 2024, 1:58 PM
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <math.h>

#define N 8

int RANK[N + 1];
int LINK[N + 1];
int NEXT[N + 1];
int HEAD = 3;

void init() {
    LINK[1] = 4;
    LINK[2] = 6;
    LINK[3] = 7;
    LINK[4] = 2;
    LINK[5] = 0;
    LINK[6] = 8;
    LINK[7] = 1;
    LINK[8] = 5;
}

void * update(void * tid) {
    int *id = (int *) tid;
    int i = *id;
    RANK[i] = 1;
    NEXT[i] = LINK[i];
    pthread_exit(NULL);
}

void parallel_1() {
    pthread_t thread[N];
    int tid[N];
    int i;
    for (i = 0; i < N; i++) {
        tid[i] = i + 1;
        pthread_create(&thread[i], NULL, update, (void *) &tid[i]);
    }

    for (i = 0; i < N; i++) {
        pthread_join(thread[i], NULL);
    }
}

void * next(void * tid) {
    int *id = (int *) tid;
    int i = *id;
    //printf("id = %d\n", i);
    if (NEXT[i] != 0) {
        RANK[i] = RANK[i] + RANK[NEXT[i]];
        NEXT[i] = NEXT[NEXT[i]];
    }    
    pthread_exit(NULL);
}

void parallel_2_1() {
    pthread_t thread[N];
    int tid[N];

    int i;
    for (i = 1; i <= N; i++) {
        //printf("i = %d\n", i);
        tid[i - 1] = i;
        pthread_create(&thread[i - 1], NULL, next, (void *) &tid[i - 1]);
    }

    for (i = 0; i < N; i++) {
        pthread_join(thread[i], NULL);
    }
}

void parallel_2() {
    const int size = log2(N);
    int k;
    for (k = 1; k <= size; k++) {
        //printf("k = %d\n", k);
        parallel_2_1();
    }
}

int main(int argc, char** argv) {

    init();
    parallel_1();
    parallel_2();
    
    int i;
    for (i = 1; i <= N; i++) {
        printf("%d ", RANK[i]);
    }
    
    printf("\n");
    printf("head rank = %d\n", RANK[HEAD]);

    return (EXIT_SUCCESS);
}

