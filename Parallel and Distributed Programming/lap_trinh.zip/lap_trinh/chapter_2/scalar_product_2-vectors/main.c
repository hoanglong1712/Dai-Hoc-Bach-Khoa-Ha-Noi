

/* 
 * File:   main.c
 * Author: 12-19-11-1-2023
 *
 * Created on February 29, 2024, 2:20 AM
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <math.h>

#define N 8 // 2^k

int A[N];
int B[N];
int C[N];

void init() {
    int i;
    for (i = 0; i < N; i++) {
        A[i] = i;
        B[i] = i;
    }
}

void * multiple(void * tid) {
    int *id = (int *) tid;
    int x = A[*id];
    int y = B[*id];
    C[*id] = x * y;
    pthread_exit(NULL);
}

void parallel_1() {
    pthread_t thread[N];
    int tid[N];
    int i;
    for (i = 0; i < N; i++) {
        tid[i] = i;
        pthread_create(&thread[i], NULL, multiple, (void *) &tid[i]);
    }

    for (i = 0; i < N; i++) {
        pthread_join(thread[i], NULL);
    }
}

struct Data {
    int j;
    int size;
};
typedef struct Data Data;

void * sum(void * pointer) {
    Data *data = (Data *) pointer;
    int j = data->j;
    int size = data->size;
    int x = C[j];
    int y = C[j + size];
    printf("j: %d %d %d\n", j, x, y);
    C[j] = x + y;
    pthread_exit(NULL);
}

void parallel_2_1(int i) {

    const int size = N / pow(2, i);
    pthread_t thread[size];
    Data data[size];
    int j;
    printf("i = %d size = %d \n", i,  size);
    
    for (j = 0; j < size; j++) {
        data[j].j = j;
        data[j].size = size;
        pthread_create(&thread[j], NULL, sum, (void *) &data[j]);
    }

    for (j = 0; j < size; j++) {
        pthread_join(thread[j], NULL);
    }
}

void parallel_2() {
    const int p = log2(N);
    int i;
    printf("p = %d\n", p);
    for (i = 1; i <= p; i++) {
        parallel_2_1(i);
    }
}

/*
 * 
 */
int main(int argc, char** argv) {
    init();
    parallel_1();
    int i;
    for (i = 0; i < N; i++) {
        printf(" %d", C[i]);
    }
    printf("\n===\n");
    parallel_2();
    /**
     * 0 1 2 3
     * 0 1 2 3
     * 0 1 4 9
     * 14
     */
    for (i = 0; i < N; i++) {
        printf(" %d", C[i]);
    }
    printf("\n");
    
    
    printf("result = %d\n", C[0]);
    return (EXIT_SUCCESS);
}

