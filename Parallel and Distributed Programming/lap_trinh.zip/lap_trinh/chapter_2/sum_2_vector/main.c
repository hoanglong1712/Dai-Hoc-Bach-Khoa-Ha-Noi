
/* 
 * File:   main.c
 * Author: 12-19-11-1-2023
 *
 * Created on February 22, 2024, 11:31 PM
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define N 10

int A[N];
int B[N];
int C[N];

void *sum(void * tid){
    int *id = (int *)tid;
    int x = A[*id];
    int y = B[*id];
    C[*id] = x + y;
    pthread_exit(NULL);
}

/*
 * 
 */
int main(int argc, char** argv) {
    
    pthread_t thread[N];
    int tid[N];
    
    int i;
    for (i = 0; i < N; i++) {
        A[i] = i;
        B[i] = i * 2;
    }
    
    for (i = 0; i < N; i++) {
        tid[i] = i;
        pthread_create(&thread[i], NULL, sum,(void *)&tid[i]);        
    }

    for (i = 0; i < N; i++) {
        pthread_join(thread[i], NULL);
    }
    
    for (i = 0; i < N; i++) {
        printf("%d ", C[i]);
    }
    
    printf("\n");
    return (EXIT_SUCCESS);
}

