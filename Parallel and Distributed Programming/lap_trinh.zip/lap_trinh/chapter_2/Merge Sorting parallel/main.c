/*
 * File:   main.c
 * Author: oracle
 *
 * Created on March 2, 2024, 4:27 AM
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <math.h>
#include <signal.h>

#define N 16


int A[N + 1];
int B[N + 1];
int C[2 * N + 1];
int J[N];

void init() {
    int tmp[] = {1, 5, 15, 18, 19, 21, 23, 24, 27, 29, 30,
        31, 32, 37, 42, 49};
    int i;
    for (i = 0; i < N; i++) {
        A[i + 1] = tmp[i];
    }
    int tmp2[] = {
        2, 3, 4, 13, 15, 19, 20, 22, 28, 29, 38, 41, 42, 43, 48, 49
    };
    for (i = 0; i < N; i++) {
        B[i + 1] = tmp2[i];
    }
}

int justGreaterOrEqual(int arr[], int start, int stop, int target) {
    int index = start - 1;
    while (start <= stop) {
        int mid = (start + stop) / 2;

        if (arr[mid] < target) {
            start = mid + 1;
        } else {
            index = mid;
            stop = mid - 1;
        }
        //printf("start %d stop %d mid %d index %d\n", start, stop, mid, index);
    }

    return index;
}

int justLessOrEqual(int arr[], int start, int stop, int target) {
    int index = justGreaterOrEqual(arr, start, stop, target);
    if (arr[index] > target) {
        return index - 1;
    }
    int i;
    for (i = index; i <= stop; i++) {
        if (arr[i] > target) {
            return i - 1;
        }
    }
    return stop;
}

struct Data {
    int i;
    int k;
};
typedef struct Data Data;

void * indexing(void * threadData) {
    Data * data = (Data *) threadData;
    int i = data->i;
    int k = data->k;

    int start = (i - 1) * k + 1;
    int stop = i * k;
    int A_k = A[stop];
    //printf("i = %d A_k = %d start = %d stop = %d\n", i, A_k, start, stop);

    J[i] = justLessOrEqual(B, 0, N, A_k);

    pthread_exit(NULL);
}

void parallel_indexing() {
    int k = log2(N);
    const int r = N / k;
    int i;
    pthread_t threads[r];
    Data data[r];

    for (i = 1; i <= r; i++) {
        data[i - 1].i = i;
        data[i - 1].k = k;
        pthread_create(&threads[i - 1], NULL, indexing, (void *) &data[i - 1]);
    }


    for (i = 0; i < r; i++) {
        pthread_join(threads[i], NULL);
        //printf("%d %d %d\n", i + 1, J[i + 1], B[J[i + 1]]);
    }

}

void s_merge(int i, int k) {
    int startA = (i - 1) * k + 1;
    int stopA = i * k;
    int startB = J[i - 1] + 1;
    int stopB = J[i];

    int startC = startA + startB - 1;
    //printf(" startA %d startB %d startC %d %d\n", startA, startB, startC,
    //stopA + stopB);

    //printf("i %d k %d\n", i, k);

    while (startA <= stopA && startB <= stopB) {
        int a = A[startA];
        int b = B[startB];
        int c;
        if (a < b) {
            c = a;
            startA++;
        } else {
            c = b;
            startB++;
        }
        C[startC] = c;
        startC++;
    }
    while (startA <= stopA) {
        C[startC] = A[startA];
        startC++;
        startA++;
    }

    while (startB <= stopB) {
        C[startC] = B[startB];
        startC++;
        startB++;
    }
    //printf("final startC %d\n", startC - 1);
}

void * merge(void * threadData) {
    Data * data = (Data *) threadData;
    int i = data->i;
    int k = data->k;


    s_merge(i, k);


    pthread_exit(NULL);
}

void parallel() {
    int k = log2(N);
    const int r = N / k;
    int i;
    pthread_t threads[r];
    Data data[r];


    for (i = 1; i <= r; i++) {
        data[i - 1].i = i;
        data[i - 1].k = k;
        pthread_create(&threads[i - 1], NULL, merge, (void *) &data[i - 1]);
    }


    for (i = 0; i < r; i++) {
        pthread_join(threads[i], NULL);
    }

}

/*
 *
 *
 */
int main(int argc, char** argv) {
    init();
    parallel_indexing();
    parallel();
    printf("\n============\n");
    int i;
    for (i = 1; i <= 2 * N; i++) {
        printf("%d ", C[i]);
    }

    // 1 2 3 4 5 13 15 15 18
    // 19 19 20 21 22 23 24
    // 27 28 29 29 30 31
    // 32 37 38 41 42 42 43 48 49 49

    return (EXIT_SUCCESS);
}