

/* 
 * File:   main.c
 * Author: 12-19-11-1-2023
 *
 * Created on February 28, 2024, 1:17 PM
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define N 64

int A[N];
int B[N];

/*
 * 
 */

void init() {
    int i;
    for (i = 0; i < N; i++) {
        A[i] = i;
    }
}

void *sum(void * tid) {
    int *id = (int *) tid;
    int i = *id;
    int x = A[2 * i];
    int y = A[2 * i + 1];
    B[i] = x + y;
    printf("%d: %d + %d = %d\n", i, x, y, B[i]);
    pthread_exit(NULL);
}

void parallel(const int p) {
    pthread_t thread[p];
    int tid[p];
    int i;

    for (i = 0; i < p; i++) {
        tid[i] = i;
        pthread_create(&thread[i], NULL, sum, (void *) &tid[i]);
    }

    for (i = 0; i < p; i++) {
        pthread_join(thread[i], NULL);
        A[i] = B[i];
    }

}

int main(int argc, char** argv) {
    init();
    int p = N / 2;

    while (p > 0) {
        printf("p = %d\n", p);
        parallel(p);
        p = p / 2;
    }
    
    printf("%d\n", A[0]);
    printf("%d\n", 32 * 63);
    pthread_exit(NULL);
    
    return (EXIT_SUCCESS);
}

