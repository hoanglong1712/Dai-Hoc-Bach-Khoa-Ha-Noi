
/* 
 * File:   main.c
 * Author: 12-19-11-1-2023
 *
 * Created on February 22, 2024, 11:49 PM
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <stdbool.h>

#define N 10

bool A[N];
bool result = true;
pthread_mutex_t lock;

void *do_work(void * tid) {
    int *id = (int *) tid;
    if (A[*id] == false) {
        pthread_mutex_lock(&lock);
        result = false;
        pthread_mutex_unlock(&lock);
    }
    pthread_exit(NULL);
}

/*
 * 
 */
int main(int argc, char** argv) {
    pthread_t thread[N];
    int tid[N];
    int i;
    for (i = 0; i < N; i++) {
        A[i] = true;
    }

    A[3] = false;
    A[4] = false;
    
    
    pthread_mutex_init(&lock, NULL);
    for (i = 0; i < N; i++) {
        tid[i] = i;
        pthread_create(&thread[i], NULL, do_work, (void *) &tid[i]);
    }

    for (i = 0; i < N; i++) {
        pthread_join(thread[i], NULL);
    }

    printf("result: %d", result);
    
    pthread_mutex_destroy(&lock);
    pthread_exit(NULL);
    return (EXIT_SUCCESS);
}

