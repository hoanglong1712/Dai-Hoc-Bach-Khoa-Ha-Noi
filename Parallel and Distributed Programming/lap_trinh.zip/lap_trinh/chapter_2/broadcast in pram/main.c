/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.c
 * Author: 12-19-11-1-2023
 *
 * Created on March 1, 2024, 12:37 PM
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <math.h>

#define N 8 // 2^k
#define TRUE 1
#define FALSE 0

int P[N + 1];

void init() {
    int i;
    for (i = 0; i <= N; i++) {
        P[i] = FALSE;
    }
}

struct Data {
    int i;
    int k;
};
typedef struct Data Data;

void * assign(void * pointer) {
    Data *data = (Data *) pointer;
    int i = data->i;
    int k = data->k;
    int index = i - pow(2, k);
    int y = P[index];
    P[i] = y;
    pthread_exit(NULL);
}

void parallel(int k) {
    int start = pow(2, k) + 1;
    int stop = pow(2, k + 1);
    const int n = stop - start + 1;
    pthread_t thread[n];
    Data data[n];
    int i;
    for (i = 0; i < n; i++) {
        data[i].i = i + start;
        data[i].k = k;
        pthread_create(&thread[i], NULL, assign, (void *) &(data[i]));
    }

    for (i = 0; i < n; i++) {
        pthread_join(thread[i], NULL);
    }

}

int main(int argc, char** argv) {
    init();

    int size = log2(N) - 1;
    P[1] = TRUE;

    int k;
    for (k = 0; k <= size; k++) {
        parallel(k);
    }

    int i;
    for (i = 1; i <= N; i++) {
        printf(" %d", P[i]);
    }


    return (EXIT_SUCCESS);
}

