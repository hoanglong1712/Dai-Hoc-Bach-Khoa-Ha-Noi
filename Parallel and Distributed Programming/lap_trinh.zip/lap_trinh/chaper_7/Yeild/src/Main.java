/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 12-19-11-1-2023
 */
public class Main {

    public static void main(String[] args) {
        /*Thread thread1 = new Thread(new Task(10));
        Thread thread2 = new Thread(new Task(20));
        Thread thread3 = new Thread(new Task(30));
        thread1.start();
        thread2.start();
        thread3.start();
         */
        NewClass.main(args);
        //NewClass.dd();
        NewClass n = new NewClass();
        n.dd();
    }
}
