/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 12-19-11-1-2023
 */
public class Task implements Runnable {
    private int lastNum;

    public Task(int lastNum) {
        this.lastNum = lastNum;
    }
    
    @Override
    public void run() {
        for (int i = 1; i <= lastNum; i++) {
            System.out.print(" " + i);
            Thread.yield();
        }
    }

}
