
import java.util.Scanner;

/**
 *
 * @author
 */
public class temperaturesstatistics {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        //Scanner object created which allows it to read users inputs
        //Declaration of variables to store the statistics

        System.out.print("Enter the number of temperatures: ");
        int temperaturenum; //number of temperatures users will enter
        double Temperaturesum = 0; //calculate sum of all temperatures
        double Temperaturemax = 0;//maximum temperature
        double Temperaturemin = 0; // minimum temperature
        double Temperature; // variable used to store each temperature that user enters
        double averagetemperature; // Average of all temperatures
        double range; // used to store the difference between the maximum temperature and the minimum temperature
        
        System.out.println("Welcome to my Temperature statistics:"); // welcomes user to the temperature statistics
        System.out.print("Please enter the number of temperature: "); // asks user to enter the number of temperatures they want to enter
        
        temperaturenum = scan.nextInt(); // reads in the number of temperature the user inputs
        scan.nextLine();
        
        // loop for temperaturenum times
        for (int i = 1; i <= temperaturenum; i++) {
            System.out.print("Enter temperature #" + i + ": ");
            Temperature = scan.nextDouble();
            scan.nextLine();

            Temperaturesum = Temperaturesum + Temperature;

            // The maximum temperature should be recorded.
            if (Temperature > Temperaturemax || i == 1) {
                Temperaturemax = Temperature;
            }

            // The minimum temperature should be recorded.
            if (Temperature < Temperaturemin || i == 1) {
                Temperaturemin = Temperature;
            }
        }
        System.out.println("");
        System.out.println("Temperature Statistics:");
        System.out.println("");
        averagetemperature = Temperaturesum / temperaturenum;
        

        /**
         * The average, max and minimum values should be displayed, truncated to
         * 2 decimal places
         */
        System.out.printf("Average Temperature: %.2f\n", averagetemperature);
        System.out.printf("Minimum Temperature: %.2f\n", Temperaturemin);
        System.out.printf("Maximum Temperature: %.2f\n", Temperaturemax);
        
        range = rangeCalculation(Temperaturemax, Temperaturemin);
        System.out.printf("Temperature Range: %.2f\n", range);
        
    }
    
    /**
     * get the range
     * @param max max value
     * @param min min value
     * @return the range
     */
    private static double rangeCalculation(double max, double min){
        return max - min;
    }
}
