#include <stdio.h>

int main(int argx, char **argv)
{
    const int n = 5;
    double u_old[n + 2][n + 2];
    double u_new[n + 2][n + 2];
    double c = 0.002, delta_t = 0.05, delta_s = 0.04;

    for (size_t i = 0; i <= n + 1; i++)
    {
        for (size_t j = 0; j <= n + 1; j++)
        {
            u_old[i][j] = 25;
        }
    }
    for (size_t j = 0; j <= n + 1; j++)
    {
        u_old[j][6] = 100;
    }

    int time = 0;
    while (time < 1)
    {
        for (size_t i = 1; i <= n; i++)
        {
            for (size_t j = 1; j <= n; j++)
            {
                u_new[i][j] = u_old[i][j] + c * delta_t /
                                                (delta_s * delta_s) *
                                                (u_old[i + 1][j] + u_old[i - 1][j] - 4 * u_old[i][j] +
                                                 u_old[i][j + 1] + u_old[i][j - 1]);
            }
        }
        for (size_t i = 1; i < n + 1; i++)
        {
            for (size_t j = 1; j < n + 1; j++)
            {
                u_old[i][j] = u_new[i][j];
            }
        }
        time++;
    }

    for (size_t i = 0; i <= n + 1; i++)
    {
        for (size_t j = 0; j <= n + 1; j++)
        {
            printf("%8.1f ", u_old[i][j]);
        }
        printf("\n");
    }
}