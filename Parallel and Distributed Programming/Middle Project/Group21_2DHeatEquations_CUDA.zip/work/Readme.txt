Commands:
compling
nvcc parallel_2D_Heat.cu -o solution

running:
./solution