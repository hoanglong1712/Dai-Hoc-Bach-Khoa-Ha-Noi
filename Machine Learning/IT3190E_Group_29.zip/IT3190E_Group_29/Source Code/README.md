The code is on Google collab
It should be speeded up with GPU

https://colab.research.google.com/drive/17IrBC8cYtRvz5_cGZ3Cy3rRfVk0JFFUP?usp=sharing

